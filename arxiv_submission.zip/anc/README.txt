Statistical reproduction
Python 3.12 was used. Install requirements.txt, then run:
  python reproduce_analysis.py
  python 04_query_cluster_bootstrap.py

The scripts read files from their own directory and regenerate all CSV results.
Query IDs Q001-Q050 and rater IDs R01-R05 are stable pseudonyms shared across
both input tables. The 2,000 rater records contain 7,939 observed scalar scores.
One missing query-text cell was linked using its original query ID after exact
agreement of all eight response/context pairs was verified. Earlier aggregate
exports inadvertently omitted that evaluator's eight records in the comparison.
No score was imputed. No query, response, abstract, or evaluator name is included.

Reliability uses complete five-rater items (387,387,386,387 respectively).
Bootstrap retains eight conditions per sampled query: 2,000 replicates, seed 20260807.
Intervals condition on the existing evaluator panel. Ordinal ratings are treated
as interval values for means, Pearson correlation, ICC, and interval alpha.
