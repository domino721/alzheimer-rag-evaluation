Statistical reproduction (Python 3.12)
python -m pip install -r requirements.txt
python reproduce_analysis.py
python 04_query_cluster_bootstrap.py
python sensitivity_analysis.py
python plot_study_design.py  # optional: reproduces Figure 1
python plot_agreement.py     # optional: reproduces Figure 2

Inputs: human_ratings_anonymized.csv (2000 rater records) and
arxiv_human_gpt_anonymized.csv (400 query-condition pairs).
There are 7939 observed human scores and 61 missing values, without imputation.
Q001-Q050 and R01-R05 are stable pseudonyms. No query, response, abstract,
evaluator name, or private ID mapping is distributed.
The 8 records with a missing query-text label were linked using the existing
query ID after response/context agreement was verified against the other files.
Reliability uses 387/387/386/387 complete five-rater items by metric.
Bootstrap: 2000 query-cluster replicates, seed 20260807, fixed expert panel.
Sensitivity: complete cases, each rater omitted, and each of eight conditions.
Ranges in the manuscript are descriptive point-estimate ranges, not intervals.
All analysis treats ordinal scores as interval where required; Spearman is
reported as a rank-based companion. No new model calls were performed.
These files reproduce the rating analysis, not the original RAG pipeline.
